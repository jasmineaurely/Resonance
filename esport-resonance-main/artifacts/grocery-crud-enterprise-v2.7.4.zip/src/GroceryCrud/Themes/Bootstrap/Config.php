<?php
namespace GroceryCrud\Themes\Bootstrap;

class Config {
    public static function getConfig() {
        return array(
            'crud_paging' => true
        );
    }
}
